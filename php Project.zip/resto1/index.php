<?php 
require_once("configs.php"); 
$page_tit="home";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!--Basic Page Needs-->
<?php include("webkit/meta.less"); ?>
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/revolution/css/layers.css">
<link rel="stylesheet" type="text/css" href="vendor/revolution/css/navigation.css">
<link rel="stylesheet" type="text/css" href="vendor/revolution/css/settings.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/daterangepicker-bootstrap/daterangepicker.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/animsition/dist/css/animsition.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="css/animate.css">
<!--===============================================================================================-->
</head>
<body  class="animsition">

<header>
<!-- Header desktop -->
<div id="wrap_header" >
<!-- Logo -->
<div class="logo col_header">
<a><img alt="logo-project" src="images/icons/logo.png"></a>
</div>
<!-- Menu -->
<?php include("webkit/menu.less"); ?>
<!-- Socials -->
<?php include("webkit/socials.less"); ?>
</div>
<!-- Header Mobile -->
<div id="wrap_header_mobile">
<!-- Logo moblie -->
<div class="logo-mobile">
<a href="#"><img alt="logo-" src="images/icons/logo-mobile.png"></a>
</div>
<!-- Button show menu -->
<div class="btn-show-menu">
<button class="btn-show-menu-mobile hamburger hamburger--squeeze" type="button">
<span class="hamburger-box">
<span class="hamburger-inner"></span>
</span>
</button>
</div>
</div>
<!-- Menu Mobile -->
<?php include("webkit/menu_m.less"); ?>
</header>
<section id="slider-project">
<!-- Slider -->
<div class="rev_slider_wrapper fullscreen-container" >
<div id="rev_slider_1" class="rev_slide fullscreenbanner" style="display: none;">
<ul>
<!-- Slide 1 -->
<li data-transition="fade" data-delay="51000">
<img src="images/slide-01.jpg" alt="Seasonal Flavours" class="rev-slidebg"
data-bgposition="center center"
data-bgfit="cover" 
data-bgrepeat="no-repeat">
<!-- VIDEO TAKEN FROM YOUTUBE: https://www.youtube.com/watch?v=OhIhAGxUEWM -->
<div class="rs-background-video-layer" 
         data-ytid="OhIhAGxUEWM" 
         data-volume="mute" 
         data-forcerewind="on" 
         data-nextslideatend="true" 
         data-videoloop="loopandnoslidestop" 
         data-videoattributes="version=3&enablejsapi=1&html5=1&hd=1&wmode=opaque&showinfo=0&rel=0&
         origin=#" 
         data-videorate="1" 
         data-videowidth="100%" 
         data-videoheight="100%" 
         data-videocontrols="none" 
         data-videostartat="00:30" 
         data-videoendat="01:21"
         data-forcecover="1" 
         data-aspectratio="16:9" 
         data-autoplay="true" 
         data-autoplayonlyfirsttime="false"
></div>

<h3 class="tp-caption tp-resizeme caption-1" 
data-frames='[{"delay":500,"speed":1800,"frame":"0","from":"x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:1;","mask":"x:[100%];y:0;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'
    data-x="center" 
    data-y="middle" 
    data-hoffset="0" 
    data-voffset="['-50','-50','-100','-120']" 
    data-width="['1140','960','720','540']"
    data-lineheight="['150', '150', '120', '100']"
    data-fontsize="['110', '110', '100', '90']"
    data-height="['auto']">Welcome to Project</h3>

<div id="btn-slide-1" class="tp-caption tp-resizeme btn-slide"
data-frames='[{"delay":2000,"speed":1500,"frame":"0","from":"y:bottom;rX:-20deg;rY:-20deg;rZ:0deg;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'
    data-x="center" 
    data-y="center" 
    data-hoffset="0" 
    data-voffset="['80','80','110','110']" 
    data-width="['910','910','380','380']"
    data-height="['auto']">
<a href="#" class="btn1">VIEW PLATES</a>
<a href="reserve.php" class="btn2">BOOK A TABLE</a>
</div>
</li>

<!-- Slide 2 -->
<li data-transition="fade">
<img src="images/slide-02.jpg" alt="Fresh Ingredients" class="rev-slidebg">

<h3 class="tp-caption tp-resizeme  caption-1" 
data-frames='[{"delay":500,"split":"chars","splitdelay":0.05,"speed":1500,"frame":"0","from":"x:[105%];z:0;rX:45deg;rY:0deg;rZ:90deg;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","to":"o:1;","ease":"Power4.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'
    data-x="center" 
    data-y="center" 
    data-hoffset="0" 
    data-voffset="['-80','-80','-140','-140']" 
    data-width="['1140','960','720','540']"
    data-lineheight="['150', '150', '120', '100']"
    data-fontsize="['110', '110', '100', '90']"
    data-height="['auto']">Fresh Ingredients</h3>

    <div  class="tp-caption tp-resizeme btn-slide caption-2"
data-frames='[{"delay":2500,"speed":1000,"frame":"0","from":"z:0;rX:0deg;rY:0;rZ:0;sX:2;sY:2;skX:0;skY:0;opacity:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","to":"o:1;","ease":"Power2.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'
    data-x="center" 
    data-y="center" 
    data-hoffset="0" 
    data-voffset="['15','15','15','5']" 
    data-width="['910','910','380','380']"
    data-height="['auto']">Fresh. projectcious. Healthy.</div>

<div id="btn-slide-2" class="tp-caption tp-resizeme btn-slide"
data-frames='[{"delay":3100,"speed":1500,"frame":"0","from":"z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'
    data-x="center" 
    data-y="center" 
    data-hoffset="0" 
    data-voffset="['110','110','140','140']" 
    data-width="['910','910','380','380']"
    data-height="['auto']">
<a href="#" class="btn1">VIEW PLATES</a>
<a href="reserve.php" class="btn2">BOOK A TABLE</a>
</div>
</li>

<!-- Slide 3 -->
<li data-transition="fade">
<img src="images/slide-03.jpg" alt="project Restaurant" class="rev-slidebg">

<h3 class="tp-caption tp-resizeme caption-1" 
data-frames='[{"delay":500,"split":"chars","splitdelay":0.05,"speed":1300,"frame":"0","from":"y:[-100%];z:0;rZ:35deg;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","to":"o:1;","ease":"Power4.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'
    data-x="center" 
    data-y="center" 
    data-hoffset="0" 
    data-voffset="['-50','-50','-100','-120']"
    data-width="['1140','960','720','540']"
    data-lineheight="['150', '150', '120', '100']"
    data-fontsize="['110', '110', '100', '90']"
    data-height="['auto']">project Restaurant</h3>

<div id="btn-slide-3" class="tp-caption tp-resizeme btn-slide"
data-frames='[{"delay":2300,"speed":1500,"frame":"0","from":"y:bottom;rZ:90deg;sX:2;sY:2;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"auto:auto;","ease":"Power3.easeInOut"}]'
    data-x="center" 
    data-y="center" 
    data-hoffset="0" 
    data-voffset="['80','80','110','110']"
    data-width="['910','910','380','380']"
    data-height="['auto']">
<a href="#" class="btn1">VIEW PLATES</a>
<a href="reserve.php" class="btn2">BOOK A TABLE</a>
</div>
</li>
</ul>
</div>
</div>
<!-- End Slider -->
</section>

<!-- Our Menu -->
<section class="our-menu" >
<div class="container">
<!-- title our menu -->
<div class="wrap-title-our-menu row">
<div class="col-12 title-our-menu">
<h6>try &amp; discover</h6>
<h2>Check our Plates</h2>
<div><br><br></div>
</div>
</div>
</div>
</section>
<!-- Banner -->
<div class="parallax-banner" >
<div class="content-banner">
<div class="text-banner wow zoomIn">
<h3>Feeling at Home</h3>
</div>
<div class="symbol-banner wow zoomIn" data-wow-delay="0.5s">
<img alt="symbol" src="images/icons/symbol-banner.png">
<div class="line-symbol-banner wow fadeInLeftBig" id="short-line-left" data-wow-delay="0.5s"></div>
<div class="line-symbol-banner wow fadeInLeftBig" id="long-line-left" data-wow-delay="0.5s"></div>
<div class="line-symbol-banner wow fadeInRightBig" id="short-line-right" data-wow-delay="0.5s"></div>
<div class="line-symbol-banner wow fadeInRightBig" id="long-line-right" data-wow-delay="0.5s"></div>
</div>
</div>
</div>
<!-- Event -->
<section id="event">
<div class="container">
<!-- title event -->
<div class="wrap-title-event row">
<div id="title-event" class="col-12">
<h6>Discover Our</h6>
<h2>Upcoming Events</h2>
</div>
<!-- EVENT 1 -->
<div class="content-event col-sm-10 col-md-8 col-lg-4 wow fadeInUp" data-wow-delay="0.2s">
<div class="img-event">
<a href="#"><img alt="picture-event" src="images/img-event-01.jpg"></a>
</div>
<h3><a class="hover-link-color" href="#">EVENT NAME</a></h3>
<p>
Soon to be announced!
</p>
<span class="date-event"><i class="fa fa-calendar" aria-hidden="true"></i> 21 June, 2017</span>
<span class="time-event"><i class="fa fa-clock-o" aria-hidden="true"></i> 10:00AM - 22:00PM</span>
</div>
<!-- EVENT 2 -->
<div class="content-event col-sm-10 col-md-8 col-lg-4 wow fadeInUp" data-wow-delay="0.4s">
<div class="img-event">
<a href="#"><img alt="picture-event" src="images/img-event-02.jpg"></a>
</div>
<h3><a class="hover-link-color" href="#">EVENT NAME</a></h3>
<p>
Soon to be announced!
</p>
<span class="date-event"><i class="fa fa-calendar" aria-hidden="true"></i> 22 June, 2017</span>
<span class="time-event"><i class="fa fa-clock-o" aria-hidden="true"></i> 19:00PM - 23:00PM</span>
</div>
<!-- EVENT 3 -->
<div class="content-event col-sm-10 col-md-8 col-lg-4 wow fadeInUp" data-wow-delay="0.6s">
<div class="img-event">
<a href="#"><img alt="picture-event" src="images/img-event-03.jpg"></a>
</div>
<h3><a class="hover-link-color" href="#">EVENT NAME</a></h3>
<p>
Soon to be announced!
</p>
<span class="date-event"><i class="fa fa-calendar" aria-hidden="true"></i> 23 June, 2017</span>
<span class="time-event"><i class="fa fa-clock-o" aria-hidden="true"></i> 10:00AM - 22:00PM</span>
</div>
</div>
</div>
</section>

<?php include("webkit/footer.less"); ?>

<!-- Back to top -->
<div class="btn-back-to-top" id="myBtn">
<span class="symbol-btn-back-to-top">
<i class="fa fa-angle-double-up" aria-hidden="true"></i>
</span>
</div>



<!--===============================================================================================-->
<script type="text/javascript" src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/wow/wow.min.js"></script>
<script type="text/javascript">
new WOW().init();
</script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/animsition/dist/js/animsition.min.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/bootstrap/js/popper.min.js"></script>
<script type="text/javascript" src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/revolution/js/jquery.themepunch.tools.min.js"></script>
<script type="text/javascript" src="vendor/revolution/js/jquery.themepunch.revolution.min.js"></script>
<script type="text/javascript" src="vendor/revolution/js/extensions/revolution.extension.video.min.js"></script>
<script type="text/javascript" src="vendor/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
<script type="text/javascript" src="vendor/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
<script type="text/javascript" src="vendor/revolution/js/extensions/revolution.extension.actions.min.js"></script>
<script type="text/javascript" src="vendor/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script type="text/javascript" src="vendor/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
<script type="text/javascript" src="vendor/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
<script type="text/javascript" src="vendor/revolution/js/extensions/revolution.extension.migration.min.js"></script>
<script type="text/javascript" src="vendor/revolution/js/extensions/revolution.extension.parallax.min.js"></script>
<script src="js/slide-custom.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/daterangepicker-bootstrap/moment.min.js"></script>
<script type="text/javascript" src="vendor/daterangepicker-bootstrap/daterangepicker.js"></script>
<!--===============================================================================================-->
<script src="js/main.js"></script>
</body>
</html>