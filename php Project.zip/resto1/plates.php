<?php 
require_once("configs.php"); 
$page_tit="plates";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!--Basic Page Needs-->
<?php include("webkit/meta.less"); ?>
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/revolution/css/layers.css">
<link rel="stylesheet" type="text/css" href="vendor/revolution/css/navigation.css">
<link rel="stylesheet" type="text/css" href="vendor/revolution/css/settings.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/daterangepicker-bootstrap/daterangepicker.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/animsition/dist/css/animsition.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="css/animate.css">
<!--===============================================================================================-->
</head>
<body  class="animsition">

<header>
<!-- Header desktop -->
<div id="wrap_header" >
<!-- Logo -->
<div class="logo col_header">
<a href="#"><img alt="logo-deli" src="images/icons/logo.png"></a>
</div>
<!-- Menu -->
<?php include("webkit/menu.less"); ?>

<!-- Socials -->
<div class="icon-header col_header">
<a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
<a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
<a href="#"><i class="fa fa-tripadvisor" aria-hidden="true"></i></a>
<a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
</div>
</div>

<!-- Header Mobile -->
<div id="wrap_header_mobile">

<!-- Logo moblie -->
<div class="logo-mobile">
<a href="index-2.html"><img alt="logo-deli" src="images/icons/logo-mobile.png"></a>
</div>

<!-- Button show menu -->
<div class="btn-show-menu">
<button class="btn-show-menu-mobile hamburger hamburger--squeeze" type="button">
<span class="hamburger-box">
<span class="hamburger-inner"></span>
</span>
</button>
</div>
</div>
</header>

<!-- Title Menu page -->
<section>
<div class="bg-title-sub-page bg-menu-page-01">
<div class="wrap-title-sub-page">
<h2 class="title-l">Our Menu</h2>
<h6 class="title-s">Home / Our Menu</h6>
</div>
</div>
</section>

<!-- Our menu 1-->
<section class="restyle-menu-03 home-onepage-menu content-reservation-03 pad-bt-80">
<div class="container">
<div class="row">
<div class="col-content col-sm-10 col-md-8 col-lg-5">
<div class="img-reservation-03 hover-img">
<img src="images/menu-03-img-01.jpg" alt="img-menu">
</div>
</div>

<div class="col-content col-sm-10 col-md-8 col-lg-7">
<div class="col-right-reservation-03">
<!-- title our menu -->
<div class="wrap-title-our-menu row">
<div class="col-12 title-our-menu">
<h6>try &amp; discover</h6>
<h2>Our Appetizer</h2>
</div>
</div>

<!-- list food -->
<div class="wrap-list-food">
<div class="row list-food">
<div class="col-12">
<!-- item food -->
<div class="item-food row wow fadeInRight" data-wow-delay="0.2s">
<div class="col-12 col-sm-10 text-list-food ">
<div class="name-price row">
<div class="name-food col-12 col-sm-auto"><a class="hover-link-color" href="product-detail.html">Pine nut sbrisalona</a></div>
<div class="line-food col">
<div class="add-line-run"></div>
</div>
</div>
<div class="row"> 
<div class="col-12 col-sm-12 info-food">
Proin lacinia nisl ut ultricies posuere nulla ut  
</div>
</div>
</div>
<div class="price-food col-12 col-sm-2">&#36;20.00</div>
</div>
</div>

<div class="col-12">
<!-- item food -->
<div class="item-food row wow fadeInRight" data-wow-delay="0.4s">
<div class="col-12 col-sm-10 text-list-food ">
<div class="name-price row">
<div class="name-food col-12 col-sm-auto"><a class="hover-link-color" href="product-detail.html">Potato gnocchi</a></div>
<div class="line-food col">
<div class="add-line-run"></div>
</div>
</div>
<div class="row"> 
<div class="col-12 col-sm-12 info-food">
Proin lacinia nisl ut ultricies posuere nulla ut 
</div>
</div>
</div>
<div class="price-food col-12 col-sm-2">&#36;10.00</div>
</div>
</div>

<div class="col-12">
<!-- item food -->
<div class="item-food row wow fadeInRight" data-wow-delay="0.6s">
<div class="col-12 col-sm-10 text-list-food ">
<div class="name-price row">
<div class="name-food col-12 col-sm-auto"><a class="hover-link-color" href="product-detail.html">Lobster caponata</a></div>
<div class="line-food col">
<div class="add-line-run"></div>
</div>
</div>
<div class="row"> 
<div class="col-12 col-sm-12 info-food">
Suspendisse sodales congue maximus
</div>
</div>
</div>
<div class="price-food col-12 col-sm-2">&#36;10.00</div>
</div>
</div>

<div class="col-12">
<!-- item food -->
<div class="item-food row wow fadeInRight" data-wow-delay="0.8s">
<div class="col-12 col-sm-10 text-list-food ">
<div class="name-price row">
<div class="name-food col-12 col-sm-auto"><a class="hover-link-color" href="product-detail.html">Pork ribollita</a></div>
<div class="line-food col">
<div class="add-line-run"></div>
</div>
</div>
<div class="row"> 
<div class="col-12 col-sm-12 info-food">
Suspendisse sodales congue maximus 
</div>
</div>
</div>
<div class="price-food col-12 col-sm-2">&#36;15.00</div>
</div>
</div>

<div class="col-12">
<!-- item food -->
<div class="item-food row wow fadeInRight" data-wow-delay="1s">
<div class="col-12 col-sm-10 text-list-food ">
<div class="name-price row">
<div class="name-food col-12 col-sm-auto"><a class="hover-link-color" href="product-detail.html">Chocolate budino</a></div>
<div class="line-food col">
<div class="add-line-run"></div>
</div>
</div>
<div class="row"> 
<div class="col-12 col-sm-12 info-food">
Interdum et malesuada fames primis in faucibus
</div>
</div>
</div>
<div class="price-food col-12 col-sm-2">&#36;15.00</div>
</div>
</div>

<div class="col-12">
<!-- item food -->
<div class="item-food row wow fadeInRight" data-wow-delay="1.2s">
<div class="col-12 col-sm-10 text-list-food ">
<div class="name-price row">
<div class="name-food col-12 col-sm-auto"><a class="hover-link-color" href="product-detail.html">Lobster caponata</a></div>
<div class="line-food col">
<div class="add-line-run"></div>
</div>
</div>
<div class="row"> 
<div class="col-12 col-sm-12 info-food">
Suspendisse sodales congue maximus
</div>
</div>
</div>
<div class="price-food col-12 col-sm-2">&#36;10.00</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>

<!-- Our menu 2-->
<section class="restyle-menu-03 home-onepage-menu content-reservation-03 special bg-color pad-bt-80">
<div class="container">
<div class="row">

<div class="s-screen col-content col-sm-10 col-md-8 col-lg-5">
<div class="img-reservation-03 hover-img">
<img src="images/home-onepage-img-menu.jpg" alt="img-menu">
</div>
</div>

<div class="col-content col-sm-10 col-md-8 col-lg-7">
<div class="col-right-reservation-03">
<!-- title our menu -->
<div class="wrap-title-our-menu row">
<div class="col-12 title-our-menu">
<h6>try &amp; discover</h6>
<h2>Our Main Meals</h2>
</div>
</div>

<!-- list food -->
<div class="wrap-list-food">
<div class="row list-food">

<div class="col-12">
<!-- item food -->
<div class="item-food row wow fadeInLeft" data-wow-delay="0.2s">
<div class="col-12 col-sm-10 text-list-food ">
<div class="name-price row">
<div class="name-food col-12 col-sm-auto"><a class="hover-link-color" href="product-detail.html">Lobster caponata</a></div>
<div class="line-food col">
<div class="add-line-run"></div>
</div>
</div>
<div class="row"> 
<div class="col-12 col-sm-12 info-food">
Suspendisse sodales congue maximus
</div>
</div>
</div>
<div class="price-food col-12 col-sm-2">&#36;10.00</div>
</div>
</div>

<div class="col-12">
<!-- item food -->
<div class="item-food row wow fadeInLeft" data-wow-delay="0.4s">
<div class="col-12 col-sm-10 text-list-food ">
<div class="name-price row">
<div class="name-food col-12 col-sm-auto"><a class="hover-link-color" href="product-detail.html">Pork ribollita</a></div>
<div class="line-food col">
<div class="add-line-run"></div>
</div>
</div>
<div class="row"> 
<div class="col-12 col-sm-12 info-food">
Suspendisse sodales congue maximus 
</div>
</div>
</div>
<div class="price-food col-12 col-sm-2">&#36;15.00</div>
</div>
</div>

<div class="col-12">
<!-- item food -->
<div class="item-food row wow fadeInLeft" data-wow-delay="0.6s">
<div class="col-12 col-sm-10 text-list-food ">
<div class="name-price row">
<div class="name-food col-12 col-sm-auto"><a class="hover-link-color" href="product-detail.html">Chocolate budino</a></div>
<div class="line-food col">
<div class="add-line-run"></div>
</div>
</div>
<div class="row"> 
<div class="col-12 col-sm-12 info-food">
Interdum et malesuada fames primis in faucibus
</div>
</div>
</div>
<div class="price-food col-12 col-sm-2">&#36;15.00</div>
</div>
</div>

<div class="col-12">
<!-- item food -->
<div class="item-food row wow fadeInLeft" data-wow-delay="0.8s">
<div class="col-12 col-sm-10 text-list-food ">
<div class="name-price row">
<div class="name-food col-12 col-sm-auto"><a class="hover-link-color" href="product-detail.html">Pine nut sbrisalona</a></div>
<div class="line-food col">
<div class="add-line-run"></div>
</div>
</div>
<div class="row"> 
<div class="col-12 col-sm-12 info-food">
Proin lacinia nisl ut ultricies posuere nulla ut  
</div>
</div>
</div>
<div class="price-food col-12 col-sm-2">&#36;20.00</div>
</div>
</div>

<div class="col-12">
<!-- item food -->
<div class="item-food row wow fadeInLeft" data-wow-delay="1s">
<div class="col-12 col-sm-10 text-list-food ">
<div class="name-price row">
<div class="name-food col-12 col-sm-auto"><a class="hover-link-color" href="product-detail.html">Potato gnocchi</a></div>
<div class="line-food col">
<div class="add-line-run"></div>
</div>
</div>
<div class="row"> 
<div class="col-12 col-sm-12 info-food">
Proin lacinia nisl ut ultricies posuere nulla ut 
</div>
</div>
</div>
<div class="price-food col-12 col-sm-2">&#36;10.00</div>
</div>
</div>

<div class="col-12">
<!-- item food -->
<div class="item-food row wow fadeInLeft" data-wow-delay="1.2s">
<div class="col-12 col-sm-10 text-list-food ">
<div class="name-price row">
<div class="name-food col-12 col-sm-auto"><a class="hover-link-color" href="product-detail.html">Pork ribollita</a></div>
<div class="line-food col">
<div class="add-line-run"></div>
</div>
</div>
<div class="row"> 
<div class="col-12 col-sm-12 info-food">
Suspendisse sodales congue maximus 
</div>
</div>
</div>
<div class="price-food col-12 col-sm-2">&#36;15.00</div>
</div>
</div>
</div>
</div>
</div>
</div>

<div class="l-screen col-content col-sm-10 col-md-8 col-lg-5">
<div class="img-reservation-03 hover-img">
<img src="images/home-onepage-img-menu.jpg" alt="img-menu">
</div>
</div>

</div>
</div>
</section>

<!-- Our menu 3-->
<section class="restyle-menu-03 home-onepage-menu content-reservation-03">
<div class="container">
<div class="row">
<div class="col-content col-sm-10 col-md-8 col-lg-5">
<div class="img-reservation-03 hover-img">
<img src="images/menu-03-img-03.jpg" alt="img-menu">
</div>
</div>

<div class="col-content col-sm-10 col-md-8 col-lg-7">
<div class="col-right-reservation-03">
<!-- title our menu -->
<div class="wrap-title-our-menu row">
<div class="col-12 title-our-menu">
<h6>try &amp; discover</h6>
<h2>Our Dessert</h2>
</div>
</div>

<!-- list food -->
<div class="wrap-list-food">
<div class="row list-food">
<div class="col-12">
<!-- item food -->
<div class="item-food row wow fadeInRight" data-wow-delay="0.2s">
<div class="col-12 col-sm-10 text-list-food ">
<div class="name-price row">
<div class="name-food col-12 col-sm-auto"><a class="hover-link-color" href="product-detail.html">Pork ribollita</a></div>
<div class="line-food col">
<div class="add-line-run"></div>
</div>
</div>
<div class="row"> 
<div class="col-12 col-sm-12 info-food">
Suspendisse sodales congue maximus 
</div>
</div>
</div>
<div class="price-food col-12 col-sm-2">&#36;15.00</div>
</div>
</div>

<div class="col-12">
<!-- item food -->
<div class="item-food row wow fadeInRight" data-wow-delay="0.4s">
<div class="col-12 col-sm-10 text-list-food ">
<div class="name-price row">
<div class="name-food col-12 col-sm-auto"><a class="hover-link-color" href="product-detail.html">Chocolate budino</a></div>
<div class="line-food col">
<div class="add-line-run"></div>
</div>
</div>
<div class="row"> 
<div class="col-12 col-sm-12 info-food">
Interdum et malesuada fames primis in faucibus
</div>
</div>
</div>
<div class="price-food col-12 col-sm-2">&#36;15.00</div>
</div>
</div>

<div class="col-12">
<!-- item food -->
<div class="item-food row wow fadeInRight" data-wow-delay="0.6s">
<div class="col-12 col-sm-10 text-list-food ">
<div class="name-price row">
<div class="name-food col-12 col-sm-auto"><a class="hover-link-color" href="product-detail.html">Pine nut sbrisalona</a></div>
<div class="line-food col">
<div class="add-line-run"></div>
</div>
</div>
<div class="row"> 
<div class="col-12 col-sm-12 info-food">
Proin lacinia nisl ut ultricies posuere nulla ut  
</div>
</div>
</div>
<div class="price-food col-12 col-sm-2">&#36;20.00</div>
</div>
</div>

<div class="col-12">
<!-- item food -->
<div class="item-food row wow fadeInRight" data-wow-delay="0.8s">
<div class="col-12 col-sm-10 text-list-food ">
<div class="name-price row">
<div class="name-food col-12 col-sm-auto"><a class="hover-link-color" href="product-detail.html">Potato gnocchi</a></div>
<div class="line-food col">
<div class="add-line-run"></div>
</div>
</div>
<div class="row"> 
<div class="col-12 col-sm-12 info-food">
Proin lacinia nisl ut ultricies posuere nulla ut 
</div>
</div>
</div>
<div class="price-food col-12 col-sm-2">&#36;10.00</div>
</div>
</div>

<div class="col-12">
<!-- item food -->
<div class="item-food row wow fadeInRight" data-wow-delay="1s">
<div class="col-12 col-sm-10 text-list-food ">
<div class="name-price row">
<div class="name-food col-12 col-sm-auto"><a class="hover-link-color" href="product-detail.html">Lobster caponata</a></div>
<div class="line-food col">
<div class="add-line-run"></div>
</div>
</div>
<div class="row"> 
<div class="col-12 col-sm-12 info-food">
Suspendisse sodales congue maximus
</div>
</div>
</div>
<div class="price-food col-12 col-sm-2">&#36;10.00</div>
</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</section>

<footer>
<div class="container">
<div class="content-footer row">
<div class="column-footer col-lg-5 col-md-8 col-sm-7">
<h3>Contact information</h3>
<ul>
<li>ADDRESS: 100 Tenth Avenue, New York City, NY 1001</li>
<li>FOR BOOKING: (044) 359 0173</li>
<li id="follow-us">FOLLOW US ON: 
<a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
<a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
<a href="#"><i class="fa fa-tripadvisor" aria-hidden="true"></i></a>
<a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
</li>
</ul>
</div>

<div class="column-footer col-lg-4 col-md-5 col-sm-7">
<h3>Restaurant hours</h3>
<ul id="restaurant-hours">
<li>
<span class="span-left">LUNCH:</span>
</li>
<li>
<span class="span-left">Monday - Friday</span>
<span class="span-right">11:30AM - 2:00PM</span>
</li>
<li>
<span class="span-left">DINNER:</span>
</li>
<li>
<span class="span-left">Monday - Friday</span>
<span class="span-right">5:30PM - 11:00PM</span>
</li>
<li>
<span class="span-left">Saturday - Sunday</span>
<span class="span-right">4:30PM - 10:00PM</span>
</li>
</ul>
<div class="line-divide first-line"></div>
</div>

<div class="column-footer col-lg-3 col-md-3 col-sm-7">
<h3>Useful links</h3>
<ul id="useful-links">
<li>
<span class="span-left">
<a href="index-2.html">Home</a>
</span> 
<span class="span-right">
<a href="shop-page.html">Features</a>
</span>
</li>
<li>
<span class="span-left">
<a href="menu-01.html">Menus</a>
</span> 
<span class="span-right">
<a href="blog-list-with-sidebar-01.html">Blog</a>
</span>
</li>
<li>
<span class="span-left">
<a href="reservation-01.html">Reservation</a>
</span> 
<span class="span-right">
<a href="contact-us.html">Contact us</a>
</span>
</li>
<li><a href="about-us.html">About us</a></li>
</ul>
<div class="line-divide second-line"></div>
</div>
</div>
</div>
<div class="wrap-bottom-footer">
<div class="container">
<div class="bottom-footer row justify-content-between">
<div class="col-12 col-sm-7">© 2017 DesignGalaxy8. All rights reserved.</div>
<div class="col-12 col-sm-5"><span>Privacy policy</span><span>Terms of use</span></div>
</div>
</div>
</div>
</footer>

<!-- Back to top -->
<div class="btn-back-to-top" id="myBtn">
<span class="symbol-btn-back-to-top">
<i class="fa fa-angle-double-up" aria-hidden="true"></i>
</span>
</div>


<!--===============================================================================================-->
<script type="text/javascript" src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/wow/wow.min.js"></script>

<script type="text/javascript">
new WOW().init();
</script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/animsition/dist/js/animsition.min.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/bootstrap/js/popper.min.js"></script>
<script type="text/javascript" src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/daterangepicker-bootstrap/moment.min.js"></script>
<script type="text/javascript" src="vendor/daterangepicker-bootstrap/daterangepicker.js"></script>
<!--===============================================================================================-->
<script src="js/main.js"></script>
</body>
</html>