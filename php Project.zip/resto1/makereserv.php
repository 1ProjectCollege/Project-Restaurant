<?php 
require_once("configs.php"); 
$page_tit="resr";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!--Basic Page Needs-->
<?php include("webkit/meta.less"); ?>
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/revolution/css/layers.css">
<link rel="stylesheet" type="text/css" href="vendor/revolution/css/navigation.css">
<link rel="stylesheet" type="text/css" href="vendor/revolution/css/settings.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/daterangepicker-bootstrap/daterangepicker.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/animsition/dist/css/animsition.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="css/animate.css">
<!--===============================================================================================-->
</head>
<body  class="animsition">

<header>
<!-- Header desktop -->
<div id="wrap_header" >
<!-- Logo -->
<div class="logo col_header">
<a href="#"><img alt="logo-deli" src="images/icons/logo.png"></a>
</div>
<!-- Menu -->
<?php include("webkit/menu.less"); ?>

<!-- Socials -->
<div class="icon-header col_header">
<a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
<a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
<a href="#"><i class="fa fa-tripadvisor" aria-hidden="true"></i></a>
<a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
</div>
</div>

<!-- Header Mobile -->
<div id="wrap_header_mobile">

<!-- Logo moblie -->
<div class="logo-mobile">
<a href="index-2.html"><img alt="logo-deli" src="images/icons/logo-mobile.png"></a>
</div>

<!-- Button show menu -->
<div class="btn-show-menu">
<button class="btn-show-menu-mobile hamburger hamburger--squeeze" type="button">
<span class="hamburger-box">
<span class="hamburger-inner"></span>
</span>
</button>
</div>
</div>
</header>

<!-- Title Menu page -->
<section>
<div class="bg-title-sub-page bg-reservation-01-page">
<div class="wrap-title-sub-page">
<h2 class="title-l">Reservation</h2>
<h6 class="title-s">Home / Reservation</h6>
</div>
</div>
</section>

<!-- Content page -->
<section class="content-reservation-02">
<div class="container">
<!-- title reservation 02 -->
<div class="wrap-title-our-menu row">
<div class="col-12 title-our-menu">
<h6>Reservation</h6>
<h2>Book a table</h2>
</div>
</div>

<form action='' method='POST' name="post_topic">
<div class="row">
<div class="wrap-input-reservation-02 col-sm-10 col-md-10 col-lg-8">
<div class="row">
<div class="col-sm-12 col-md-6">
<div class="row">
<div class="col-field-input left col-md-12 wow fadeInLeft">
<select class="chose-people" name="chose-people">
<option value="1 people">1 people</option>
<option value="2 people">2 people</option>
<option value="3 people">3 people</option>
<option value="4 people">4 people</option>
<option value="5 people">5 people</option>
<option value="6 people">6 people</option>
</select>
</div>

<div class="col-field-input left col-md-12 chose-calendar wow fadeInLeft">
<input class="my-calendar" type="text" name="calender">
</div>

<div class="col-field-input left col-md-12 wow fadeInLeft">
<select class="chose-time" name="chose-time">
<option value="5:00 PM">5:00 PM</option>
<option value="6:00 PM">6:00 PM</option>
<option value="7:00 PM">7:00 PM</option>
<option value="8:00 PM">8:00 PM</option>
<option value="9:00 PM">9:00 PM</option>
</select>
</div>
</div>
</div>

<div class="col-sm-12 col-md-6">
<div class="row">
<div class="col-field-input right col-md-12 wow fadeInRight">
<input class="your-info your-name" type="text" name="your-name" placeholder="Your name">
</div>

<div class="col-field-input right col-md-12 wow fadeInRight">
<input class="your-info your-name" type="text" name="your-lname" placeholder="Your last name">
</div>

<div class="col-field-input right col-md-12 wow fadeInRight">
<input class="your-info your-phone" type="text" name="your-phone" placeholder="Your phone">
</div>
</div>
</div>
</div>

<textarea class="your-info special-notes wow fadeInUp" data-wow-delay="0.5s" name="special-notes" placeholder="Special notes"></textarea>

<input class="btn-reservation-02" name="createRecruit" type="submit" value="SUBMIT">


</div>
</div>
</form>
<?php
if(isset($_POST["createRecruit"])){
$sql = "INSERT INTO reservations (name, people, tele, date, hour, special)VALUES('".$_POST["your-name"]."', '".$_POST["chose-people"]."', '".$_POST["your-phone"]."', '".$_POST["calender"]."', '".$_POST["chose-time"]."', '".$_POST["special-notes"]."')";
if ($restodb->query($sql) === TRUE) {
echo "<script type= 'text/javascript'>alert('New record created successfully');</script>";
echo "<meta http-equiv='refresh'content='10;url=reserve.php'>";
echo $sql;
} else {
echo "<script type= 'text/javascript'>alert('Error: " . $sql . "<br>" . $restodb->error."');</script>";
echo "<meta http-equiv='refresh'content='10;url=makereserv.php'>";
echo $sql;
}
}
?>
</div>
</section>
<footer>
<div class="container">
<div class="content-footer row">
<div class="column-footer col-lg-5 col-md-8 col-sm-7">
<h3>Contact information</h3>
<ul>
<li>ADDRESS: 100 Tenth Avenue, New York City, NY 1001</li>
<li>FOR BOOKING: (044) 359 0173</li>
<li id="follow-us">FOLLOW US ON: 
<a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
<a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
<a href="#"><i class="fa fa-tripadvisor" aria-hidden="true"></i></a>
<a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
</li>
</ul>
</div>

<div class="column-footer col-lg-4 col-md-5 col-sm-7">
<h3>Restaurant hours</h3>
<ul id="restaurant-hours">
<li>
<span class="span-left">LUNCH:</span>
</li>
<li>
<span class="span-left">Monday - Friday</span>
<span class="span-right">11:30AM - 2:00PM</span>
</li>
<li>
<span class="span-left">DINNER:</span>
</li>
<li>
<span class="span-left">Monday - Friday</span>
<span class="span-right">5:30PM - 11:00PM</span>
</li>
<li>
<span class="span-left">Saturday - Sunday</span>
<span class="span-right">4:30PM - 10:00PM</span>
</li>
</ul>
<div class="line-divide first-line"></div>
</div>

<div class="column-footer col-lg-3 col-md-3 col-sm-7">
<h3>Useful links</h3>
<ul id="useful-links">
<li>
<span class="span-left">
<a href="index-2.html">Home</a>
</span> 
<span class="span-right">
<a href="shop-page.html">Features</a>
</span>
</li>
<li>
<span class="span-left">
<a href="menu-01.html">Menus</a>
</span> 
<span class="span-right">
<a href="blog-list-with-sidebar-01.html">Blog</a>
</span>
</li>
<li>
<span class="span-left">
<a href="reservation-01.html">Reservation</a>
</span> 
<span class="span-right">
<a href="contact-us.html">Contact us</a>
</span>
</li>
<li><a href="about-us.html">About us</a></li>
</ul>
<div class="line-divide second-line"></div>
</div>
</div>
</div>
<div class="wrap-bottom-footer">
<div class="container">
<div class="bottom-footer row justify-content-between">
<div class="col-12 col-sm-7">© 2017 DesignGalaxy8. All rights reserved.</div>
<div class="col-12 col-sm-5"><span>Privacy policy</span><span>Terms of use</span></div>
</div>
</div>
</div>
</footer>

<!-- Back to top -->
<div class="btn-back-to-top" id="myBtn">
<span class="symbol-btn-back-to-top">
<i class="fa fa-angle-double-up" aria-hidden="true"></i>
</span>
</div>

<!--===============================================================================================-->
<script type="text/javascript" src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/wow/wow.min.js"></script>

<script type="text/javascript">
new WOW().init();
</script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/animsition/dist/js/animsition.min.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/bootstrap/js/popper.min.js"></script>
<script type="text/javascript" src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/daterangepicker-bootstrap/moment.min.js"></script>
<script type="text/javascript" src="vendor/daterangepicker-bootstrap/daterangepicker.js"></script>
<!--===============================================================================================-->
<script src="js/main.js"></script>
</div>
</body>
</html>