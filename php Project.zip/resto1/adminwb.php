<?php 
require_once("configs.php");
require_once("check.php"); 
$page_tit="admin";
if($login_rank < 1)
{
die('
<meta http-equiv="refresh" content="2;url=index.php"/>
');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!--Basic Page Needs-->
<?php include("webkit/meta.less"); ?>
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/revolution/css/layers.css">
<link rel="stylesheet" type="text/css" href="vendor/revolution/css/navigation.css">
<link rel="stylesheet" type="text/css" href="vendor/revolution/css/settings.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/daterangepicker-bootstrap/daterangepicker.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/animsition/dist/css/animsition.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="css/animate.css">
<!--===============================================================================================-->
</head>
<body  class="animsition">

<header>
<!-- Header desktop -->
<div id="wrap_header" >
<!-- Logo -->
<div class="logo col_header">
<a href="#"><img alt="logo-deli" src="images/icons/logo.png"></a>
</div>
<!-- Menu -->
<?php include("webkit/menu.less"); ?>

<!-- Socials -->
<div class="icon-header col_header">
<a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
<a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
<a href="#"><i class="fa fa-tripadvisor" aria-hidden="true"></i></a>
<a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
</div>
</div>

<!-- Header Mobile -->
<div id="wrap_header_mobile">

<!-- Logo moblie -->
<div class="logo-mobile">
<a href="index-2.html"><img alt="logo-deli" src="images/icons/logo-mobile.png"></a>
</div>

<!-- Button show menu -->
<div class="btn-show-menu">
<button class="btn-show-menu-mobile hamburger hamburger--squeeze" type="button">
<span class="hamburger-box">
<span class="hamburger-inner"></span>
</span>
</button>
</div>
</div>
</header>

<!-- Title Menu page -->
<section>
<div class="bg-title-sub-page bg-reservation-01-page">
<div class="wrap-title-sub-page">
<h2 class="title-l">Admin Panel</h2>
<h6 class="title-s">Tables / Reservation / Verify</h6>
</div>
</div>
</section>

<?php
if ($result = $restodb->query("select * from reservations order by id"))
{
if ($result->num_rows != 0)
{
$totalresults = $result->num_rows;
{
$row = $result->fetch_row();
// Displaying the Objects from the Database
echo '
<div class="wrap-input-find col-12 col-sm-12 col-md-10">
<div class="row">
<div class="col-10 col-sm-8 col-md-1" style="padding-right: 0px!important; padding-left: 0px!important;">
<span class="select2 select2-container select2-container--default select2-container--focus" dir="ltr">
<span class="select2-selection select2-selection--single" role="combobox">
<span class="select2-selection__rendered" id="select2-chose-people-ye-container" title="' . $row[0] . '">' . $row[0] . '</span></span>
</div>
<div class="col-10 col-sm-8 col-md-3" style="padding-right: 0px!important; padding-left: 0px!important;"">
<span class="select2 select2-container select2-container--default select2-container--focus" dir="ltr">
<span class="select2-selection select2-selection--single" role="combobox">
<span class="select2-selection__rendered" id="select2-chose-people-ye-container" title="' . $row[1] . '">' . $row[1] . '</span></span>
</div>
<div class="col-10 col-sm-8 col-md-2" style="padding-right: 0px!important; padding-left: 0px!important;"">
<span class="select2 select2-container select2-container--default select2-container--focus" dir="ltr">
<span class="select2-selection select2-selection--single" role="combobox">
<center><span class="select2-selection__rendered" id="select2-chose-people-ye-container" title="' . $row[3] . '">' . $row[3] . '</span></center></span>
</div>
<div class="col-10 col-sm-8 col-md-5" style="padding-right: 0px!important; padding-left: 0px!important;"">
<span style="width: 25% !important;" class="select2 select2-container select2-container--default select2-container--focus" dir="ltr">
<span class="select2-selection select2-selection--single" role="combobox">
<center><span class="select2-selection__rendered" id="select2-chose-people-ye-container" title="' . $row[4] . '">' . $row[4] . '</span></center></span>
</div>
';
}
}
else
{
echo "No Reservations at the moment!";
}
}
// Query Error
else
{
echo "Error: " . $restodb->error;
}
echo "</div></div>";
?>

<?php include("webkit/footer.less"); ?>
<!-- Back to top -->
<div class="btn-back-to-top" id="myBtn">
<span class="symbol-btn-back-to-top">
<i class="fa fa-angle-double-up" aria-hidden="true"></i>
</span>
</div>

<!--===============================================================================================-->
<script type="text/javascript" src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/wow/wow.min.js"></script>

<script type="text/javascript">
new WOW().init();
</script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/animsition/dist/js/animsition.min.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/bootstrap/js/popper.min.js"></script>
<script type="text/javascript" src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/daterangepicker-bootstrap/moment.min.js"></script>
<script type="text/javascript" src="vendor/daterangepicker-bootstrap/daterangepicker.js"></script>
<!--===============================================================================================-->
<script src="js/main.js"></script>
</div>
</body>
</html>