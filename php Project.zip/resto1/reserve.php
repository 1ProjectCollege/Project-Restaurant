<?php 
require_once("configs.php"); 
$page_tit="resr";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!--Basic Page Needs-->
<?php include("webkit/meta.less"); ?>
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/revolution/css/layers.css">
<link rel="stylesheet" type="text/css" href="vendor/revolution/css/navigation.css">
<link rel="stylesheet" type="text/css" href="vendor/revolution/css/settings.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/daterangepicker-bootstrap/daterangepicker.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/animsition/dist/css/animsition.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="css/animate.css">
<!--===============================================================================================-->
</head>
<body  class="animsition">

<header>
<!-- Header desktop -->
<div id="wrap_header" >
<!-- Logo -->
<div class="logo col_header">
<a href="#"><img alt="logo-deli" src="images/icons/logo.png"></a>
</div>
<!-- Menu -->
<?php include("webkit/menu.less"); ?>

<!-- Socials -->
<div class="icon-header col_header">
<a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
<a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
<a href="#"><i class="fa fa-tripadvisor" aria-hidden="true"></i></a>
<a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
</div>
</div>

<!-- Header Mobile -->
<div id="wrap_header_mobile">

<!-- Logo moblie -->
<div class="logo-mobile">
<a href="index-2.html"><img alt="logo-deli" src="images/icons/logo-mobile.png"></a>
</div>

<!-- Button show menu -->
<div class="btn-show-menu">
<button class="btn-show-menu-mobile hamburger hamburger--squeeze" type="button">
<span class="hamburger-box">
<span class="hamburger-inner"></span>
</span>
</button>
</div>
</div>
</header>

<!-- Title Menu page -->
<section>
<div class="bg-title-sub-page bg-reservation-01-page">
<div class="wrap-title-sub-page">
<h2 class="title-l">Reservation</h2>
<h6 class="title-s">Home / Reservation</h6>
</div>
</div>
</section>

<!-- Content page -->
<section class="content-reservation-01">
<div class="container">
<div class="text-reservation-01 row">
<div class="col-lg-6 wow fadeInDown">
<h3>Reserve Online</h3>
<p>
Located in Athens, Greece is inspired by the classical Ancient-Greek ‘olive’ clubs. The restaurant serves contemporary Greek cuisine using seasonal Ancient ingredients with a strong focus on the olives and seasoning sharing dishes in a convivial environment.
</p>
<p>
You can get your table today by just reserving on our new Reservations list that we have designed just for your needs! Also don't forget to call us for more details at: (210) 689 0173
</p>
</div>
<div class="col-lg-1">
<div class="my-line-divide"></div>
</div>
<div class="col-lg-5 wow fadeInDown">
<h3>for Event Booking</h3>
<p>
We do offer Event Booking and ofcourse Restaurant Booking for special occusations such as weddings, parties, etc.
</p>
<p>
We have special dishes and ofcourse we accept any kind of dish requests that you can't find on our ‘Plates’ section of our site. In those special occusations we do offer our finest wines!
</p>
</div>
</div>

<form>
<div class="input-reservation row wow flipInX" data-wow-delay="0.5s">
<div class="col-5 col-sm-3 col-md-2">
<a href="makereserv.php" class="btn-find-table">
<input type="button" class="btn-find-table" value="MAKE A RESERVATION" />
</a>
</div>
</div>
</form>
</div>
</section>
<?php include("webkit/footer.less"); ?>
<!-- Back to top -->
<div class="btn-back-to-top" id="myBtn">
<span class="symbol-btn-back-to-top">
<i class="fa fa-angle-double-up" aria-hidden="true"></i>
</span>
</div>

<!--===============================================================================================-->
<script type="text/javascript" src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/wow/wow.min.js"></script>

<script type="text/javascript">
new WOW().init();
</script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/animsition/dist/js/animsition.min.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/bootstrap/js/popper.min.js"></script>
<script type="text/javascript" src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/daterangepicker-bootstrap/moment.min.js"></script>
<script type="text/javascript" src="vendor/daterangepicker-bootstrap/daterangepicker.js"></script>
<!--===============================================================================================-->
<script src="js/main.js"></script>
</div>
</body>
</html>