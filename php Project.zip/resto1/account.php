<?php
require_once("configs.php"); 
$page_tit="reg";
@session_start();
$user_check=@$_SESSION['email'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!--Basic Page Needs-->
<?php include("webkit/meta.less"); ?>
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/revolution/css/layers.css">
<link rel="stylesheet" type="text/css" href="vendor/revolution/css/navigation.css">
<link rel="stylesheet" type="text/css" href="vendor/revolution/css/settings.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/daterangepicker-bootstrap/daterangepicker.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="vendor/animsition/dist/css/animsition.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="css/animate.css">
<!--===============================================================================================-->
</head>
<body  class="animsition">

<header>
<!-- Header desktop -->
<div id="wrap_header" >
<!-- Logo -->
<div class="logo col_header">
<a href="#"><img alt="logo-deli" src="images/icons/logo.png"></a>
</div>
<!-- Menu -->
<?php include("webkit/menu.less"); ?>

<!-- Socials -->
<div class="icon-header col_header">
<a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
<a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
<a href="#"><i class="fa fa-tripadvisor" aria-hidden="true"></i></a>
<a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
</div>
</div>

<!-- Header Mobile -->
<div id="wrap_header_mobile">

<!-- Logo moblie -->
<div class="logo-mobile">
<a href="index-2.html"><img alt="logo-deli" src="images/icons/logo-mobile.png"></a>
</div>

<!-- Button show menu -->
<div class="btn-show-menu">
<button class="btn-show-menu-mobile hamburger hamburger--squeeze" type="button">
<span class="hamburger-box">
<span class="hamburger-inner"></span>
</span>
</button>
</div>
</div>

<!-- Menu Mobile -->
<?php include("webkit/menu_m.less"); ?>
</header>

<!-- Title Menu page -->
<section>
<div class="bg-title-sub-page bg-reservation-01-page">
<div class="wrap-title-sub-page">
<h2 class="title-l">Registration</h2>
<h6 class="title-s">Home / Registration</h6>
</div>
</div>
</section>

<!-- Content page -->
<section class="content-reservation-01">
<div class="container">
<div class="text-reservation-01 row">
<div class="col-lg-6 wow fadeInDown">
<h3>Register an account</h3>
<p>
Registering an account lets you do reservations to successfully reserve a table if you want to visit our restaurant.
</p>
<p>
For further information or reservations via phone you can call us at: INSERT PHONE HERE
</p>
<a class="btn-log-account-test" href="register.php">REGISTER</a>
</div>
<div class="col-lg-1">
<div class="my-line-divide"></div>
</div>
<div class="col-lg-5 wow fadeInDown">
<h3>Login</h3>
<p>
Login with your account to reserve a table now.
</p>
<?php if(isset($_SESSION['email'])){ ?>
<p><span>You are logged!</span> Welcome, <color style="color: #007bff!important;"><?php echo $_SESSION['email']; ?></color></p>
<p><span><a class="btn-log-account-test" href="logout.php">LOGOUT</a></span></p>
<?php }else{ ?>
<p><span><a class="btn-log-account-test" href="login.php">LOGIN</a></span></p>
<?php } ?>
</div>
</div>
</div>
</section>

<?php include("webkit/footer.less"); ?>
<!-- Back to top -->
<div class="btn-back-to-top" id="myBtn">
<span class="symbol-btn-back-to-top">
<i class="fa fa-angle-double-up" aria-hidden="true"></i>
</span>
</div>

<!--===============================================================================================-->
<script type="text/javascript" src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/wow/wow.min.js"></script>

<script type="text/javascript">
new WOW().init();
</script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/animsition/dist/js/animsition.min.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/bootstrap/js/popper.min.js"></script>
<script type="text/javascript" src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
<script type="text/javascript" src="vendor/daterangepicker-bootstrap/moment.min.js"></script>
<script type="text/javascript" src="vendor/daterangepicker-bootstrap/daterangepicker.js"></script>
<!--===============================================================================================-->
<script src="js/main.js"></script>
</div>
</body>

<!-- Mirrored from templates.smilethemes.com/deli/reservation-01.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 29 Dec 2017 18:14:56 GMT -->
</html>